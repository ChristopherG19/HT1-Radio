/******************************************************************

Christopher García 20541
Rodrigo Barrera 20807
3er. Semestre UVG
HT1-Estructura de datos
Fecha de creación: 16/01/2021 15:00 hrs.
Fecha de última modificación: 21/01/2021 

******************************************************************/
public interface ClassRadio_2 {
	
	public abstract boolean isON();
	public abstract void  encenderRadio();
	public abstract void apagarRadio();
	public abstract void aumentarEmisora();
	public abstract void guardarEmisora();
	public abstract void cambiarEmisora();
	public abstract void seleccionarEmisora();
	
}

/******************************************************************

Christopher García 20541
Rodrigo Barrera 20807
3er. Semestre UVG
HT1-Estructura de datos
Fecha de creación: 16/01/2021 15:00 hrs.
Fecha de última modificación: 21/01/2021 

******************************************************************/
import java.util.Scanner;

public class RadioCrtl_2 implements ClassRadio_2{
	
	private boolean isOn;
	private int frequency_AM;
	private float frequency_FM;
	private String frecuanciaRadio;
	private int Guardado [];
	Scanner entrada;

	public RadioCrtl_2() {
		
		isOn=false;
		frecuanciaRadio="AM";
		frequency_AM=530;
		frequency_FM=87.9f;
		Guardado=new int[12];
		entrada = new Scanner(System.in);
		Guardado[0]=530;
		Guardado[1]=(int) 87.9;
		Guardado[2]=530;
		Guardado[3]=(int) 87.9;
		Guardado[4]=530;
		Guardado[5]=(int) 87.9;
		Guardado[6]=530;
		Guardado[7]=(int) 87.9;
		Guardado[8]=530;
		Guardado[9]=(int) 87.9;
		Guardado[10]=530;
		Guardado[11]=(int) 87.9;
		
	}

	@Override
	public boolean isON() {
		
		return isOn;
		
	}

	@Override
	public void encenderRadio() {
		
		isOn=true;
		
	}

	@Override
	public void apagarRadio() {
		
		isOn=false;
	}
	

	@Override
	public void aumentarEmisora() {
		if(frecuanciaRadio.equalsIgnoreCase("am")) {
			
			frequency_AM+=10;
			
			if(frequency_AM>1610) {
				
				frequency_AM=530;
				
			}
			
			System.out.println("La frecuencia sintonizada es: "+frequency_AM);
			
		}
		
		else {
				
			frequency_FM+=0.2;
			
			if(frequency_FM>107.9) {
				
				frequency_FM=87.9f;
				
				
			}
			
			System.out.println("La frecuencia sintonizada es: "+frequency_FM);
			
			
		}
	
	}


	@Override
	public void guardarEmisora() {
		
		int opcion=0;
		
		if(frecuanciaRadio.equalsIgnoreCase("am")) {
		
			System.out.println("Ingrese una posici�n del 1 al 12 para guardar la emisora: ");
			opcion=entrada.nextInt();
			
			Guardado[opcion-1]=frequency_AM;
			
			System.out.println("Usted guardo la emisora "+ frequency_AM+ " en la posici�n:  " + opcion);
		
		}
		
		else if(frecuanciaRadio.equalsIgnoreCase("fm")) {
			
			System.out.println("Ingrese una posici�n del 1 al 12 para guardar la emisora: ");
			opcion=entrada.nextInt();
			
			Guardado[opcion-1]=(int) frequency_FM;
			
			System.out.println("Usted guardo la emisora" +frequency_FM +  "en la posici�n:  " + opcion);
			
			
		}
		else {
			
			System.out.println("Lo sentimos frecuencia no valida...");
			
		}
		
	}

	@Override
	public void cambiarEmisora() {
		
		System.out.println("Ingrese la frecuencia de Radio que desea escuchar (AM O FM): ");
		frecuanciaRadio=entrada.nextLine();
	
	}

	@Override
	public void seleccionarEmisora() {
		
		int opcion=0;
		
		System.out.println("Ingrese una posici�n del 1 al 12 para escuchar la frecuencia guardada: ");
		opcion=entrada.nextInt();
		
		System.out.println("Usted selecciono la emisora: "+ Guardado[opcion-1]);
		
		
	}

	
	
	

}

/******************************************************************

Christopher García 20541
Rodrigo Barrera 20807
3er. Semestre UVG
HT1-Estructura de datos
Fecha de creación: 16/01/2021 15:00 hrs.
Fecha de última modificación: 21/01/2021 

******************************************************************/
import java.util.Scanner;

public class ClaseMain_2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		RadioCrtl_2 radio=new RadioCrtl_2();
		Scanner entrada=new Scanner(System.in);
		
		int opcion=0,opcion1=0;
		
		System.out.println("------------RADIO R AND CHR --------------");
		
		while (!radio.isON()) {

			System.out.println("�Desea encender la radio?" + "\n1. SI " + "\n2. NO");
			opcion=entrada.nextInt();
				
			try {
				
				switch(opcion) {
				
				case 1:
					
					System.out.println("Radio Encendida");
					radio.encenderRadio();
					break;
					
					
				case 2:
					
					System.out.println("Ingrese una opcion...");
					break;
					
					
				default:
					
					System.out.println("Fuera de rango...");
					
					break;

			}
			
			}catch(Exception e) {
				
				System.out.println("Solo deben ser datos numericos");

				
			}
			
			
			
		}
		
		while(radio.isON()==true) {
			
			System.out.println("�Que acci�n desea realizar? "+ "\n1. Apagar " + "\n2. Escoger frecuencia (AM O FM) "+"\n3. Guardar una Emisora" + "\n4. Siguiente emisora " + "\n5. Seleccionar emisora guardada");
			opcion1=entrada.nextInt();
			
			try {
				
				switch(opcion1) {
				
				case 1:
					
					System.out.println("Radio Apagada");
					radio.apagarRadio();
					break;
				case 2:
					
					radio.cambiarEmisora();
					break;
				case 3:
					radio.guardarEmisora();
					break;
				case 4:
					radio.aumentarEmisora();
					break;
				case 5:
					radio.seleccionarEmisora();
					break;
				default:
					System.out.println("Fuera de rango...");
					
				
				
				}
				
				
				
			}catch(Exception e) {
				
				System.out.println("Solo deben ser datos numericos");
				
			}
			
			
		}
		
		entrada.close();
	}

}

/**
 * 
 */

/**
 * @author barre
 *
 */
public interface ClassRadio_1 {
	
	 boolean isON();
	 void  encender();
	 void apagar();
	 void incrementar();
	 void disminuir();
	 void asignar();
	 void frecuencia();
	
}

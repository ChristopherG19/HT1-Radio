import java.util.Scanner;

/**
 * 
 */

/**
 * @author barre
 *
 */
public class RadioCrtl_1 implements ClassRadio_1{
	
	private boolean isOn;
	private int frequency_AM;
	private float frequency_FM;
	private String frecuanciaRadio;
	private int Guardado [];
	Scanner entrada;

	public RadioCrtl_1() {
		
		isOn=false;
		frecuanciaRadio="AM";
		frequency_AM=530;
		frequency_FM=87.9f;
		Guardado=new int[12];
		entrada = new Scanner(System.in);
		Guardado[0]=530;
		Guardado[1]=(int) 87.9;
		Guardado[2]=530;
		Guardado[3]=(int) 87.9;
		Guardado[4]=530;
		Guardado[5]=(int) 87.9;
		Guardado[6]=530;
		Guardado[7]=(int) 87.9;
		Guardado[8]=530;
		Guardado[9]=(int) 87.9;
		Guardado[10]=530;
		Guardado[11]=(int) 87.9;
		
	}

	@Override
	public boolean isON() {
		
		return isOn;
		
	}

	@Override
	public void encender() {
		
		isOn=true;
		
	}

	@Override
	public void apagar() {
		
		isOn=false;
	}
	

	@Override
	public void incrementar() {
		if(frecuanciaRadio.equalsIgnoreCase("am")) {
			
			frequency_AM+=10;
			
			if(frequency_AM>1610) {
				
				frequency_AM=530;
				
			}
			
			System.out.println("La frecuencia sintonizada es: "+frequency_AM);
			
		}
		
		else {
				
			frequency_FM+=0.2;
			
			if(frequency_FM>107.9) {
				
				frequency_FM=87.9f;
				
				
			}
			
			System.out.println("La frecuencia sintonizada es: "+frequency_FM);
			
			
		}
	
	}

	@Override
	public void disminuir() {
		
		if(frecuanciaRadio.equalsIgnoreCase("am")) {
			
			frequency_AM-=10;
			
			if(frequency_AM<530) {
				
				frequency_AM=530;
				
			}
			
			System.out.println("La frecuencia sintonizada es: " + frequency_AM);
			
		}
		
		else {
				
			frequency_FM-=0.2;
			
			if(frequency_FM<87.9) {
				
				frequency_FM=87.9f;
				
				
			}
			
			System.out.println("La frecuencia sintonizada es: " + frequency_FM);
			
			
		}
		
		
	}

	@Override
	public void asignar() {
		
		int opcion=0;
		
		if(frecuanciaRadio.equalsIgnoreCase("am")) {
		
			System.out.println("Ingrese una posici�n del 1 al 12 para guardar la emisora: ");
			opcion=entrada.nextInt();
			
			Guardado[opcion-1]=frequency_AM;
			
			System.out.println("Usted guardo la emisora "+ frequency_AM+ " en la posici�n:  " + opcion);
		
		}
		
		else {
			
			System.out.println("Ingrese una posici�n del 1 al 12 para guardar la emisora: ");
			opcion=entrada.nextInt();
			
			Guardado[opcion-1]=(int) frequency_FM;
			
			System.out.println("Usted guardo la emisora" +frequency_FM +  "en la posici�n:  " + opcion);
			
			
		}
		
	}

	@Override
	public void frecuencia() {
		
		System.out.println("Ingrese la frecuencia de Radio que desea escuchar (AM O FM): ");
		frecuanciaRadio=entrada.nextLine();
	
	}
	
	

}

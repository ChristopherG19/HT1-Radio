/******************************************************************

Christopher García 20541
Rodrigo Barrera 20807
3er. Semestre UVG
HT1-Estructura de datos
Fecha de creación: 16/01/2021 15:00 hrs.
Fecha de última modificación: 21/01/2021 

******************************************************************/

/*Se importa Scanner para poder solicitar datos al usuario,
  al igual que JUnit para poder realizar pruebas unitarias*/
import static org.junit.Assert.assertEquals;

import java.util.Scanner;

import org.junit.Test;

//Inicio de la clase RadioCrtl que implementa la interfaz de RadioGeneral
public class RadioCrtl implements RadioGeneral{
	
	/******Atributos******/
	private boolean isOn;
	private int frequency_AM;
	private float frequency_FM;
	private String frecuanciaRadio;
	private int Guardado [];
	Scanner entrada;
	
	/***Metodo constructor***/
	public RadioCrtl() {
		
		//Se inicia la radio con estas características
		isOn=false;
		frecuanciaRadio="AM";
		frequency_AM=530;
		frequency_FM=87.9f;
		Guardado=new int[12];
		entrada = new Scanner(System.in);
		Guardado[0]=530;
		Guardado[1]=(int) 87.9;
		Guardado[2]=530;
		Guardado[3]=(int) 87.9;
		Guardado[4]=530;
		Guardado[5]=(int) 87.9;
		Guardado[6]=530;
		Guardado[7]=(int) 87.9;
		Guardado[8]=530;
		Guardado[9]=(int) 87.9;
		Guardado[10]=530;
		Guardado[11]=(int) 87.9;
		
	}
	
	/*Metodo que devuelve el estado en el que se encuentra la radio*/
	@Override
	public boolean isON() {
		return isOn;
	}
	
	/*Metodo que modifica el valor a true cuando la radio esta encendida*/
	@Override
	public void encender() {
		isOn=true;
	}
	
	/*Metodo que modifica el valor a false cuando la radio esta apagada*/
	@Override
	public void apagar() {
		isOn=false;
	}
	
	/*Metodo que incrementa el valor del atributo de la frecuencia*/
	@Override
	public void incrementar() {
		if(frecuanciaRadio.equalsIgnoreCase("am")) {
			
			frequency_AM+=10;
			
			if(frequency_AM>1610) {	
				frequency_AM=530;
			}
			
			System.out.println("La frecuencia sintonizada es: "+frequency_AM + "\n");
			
		} else {
				
			frequency_FM+=0.2;
			
			if(frequency_FM>107.9) {	
				frequency_FM=87.9f;
			}
	
			System.out.println("La frecuencia sintonizada es: "+frequency_FM + "\n");
		}
	}

	/*Metodo que sirve para guardar una frecuencia en la lista devolviendo true si es "AM" o false si es "FM"*/
	@Override
	public boolean asignar(int num) {
		
		int opcion=0;
		
		if(frecuanciaRadio.equalsIgnoreCase("am")) {
		
			System.out.println("Ingrese una posicion del 1 al 12 para guardar la emisora: ");
			opcion=entrada.nextInt();
			
			Guardado[opcion-1]=frequency_AM;
			
			System.out.println("Usted guardo la emisora "+ frequency_AM+ " en la posicion:  " + opcion + "\n");
			return true;
		
		}
		
		else if(frecuanciaRadio.equalsIgnoreCase("fm")) {
			
			System.out.println("Ingrese una posici�n del 1 al 12 para guardar la emisora: ");
			opcion=entrada.nextInt();
			
			Guardado[opcion-1]=(int) frequency_FM;
			
			System.out.println("Usted guardo la emisora " +frequency_FM +  " en la posicion:  " + opcion + "\n");
			
			return false;
		}
		else {
			
			System.out.println("Lo sentimos frecuencia no valida...\n");
			return (Boolean) null;
			
		}
		
	}
	
	/*Metodo que sirve para cambiar el valor del tipo de frecuencia "AM" o "FM"*/
	@Override
	public void frecuencia() {
		
		System.out.println("Ingrese la frecuencia de Radio que desea escuchar (AM O FM): ");
		frecuanciaRadio=entrada.nextLine();

	}
	
	/*Metodo que sirve para retornar true cuando muestra una emisora guardada*/
	@Override
	public boolean emisora(int num) {
		
		System.out.println("Ingrese una posicion del 1 al 12 para escuchar la frecuencia guardada: ");
		num=entrada.nextInt();
		
		System.out.println("Usted selecciono la emisora: " + Guardado[num-1] + "\n");
		return true;
		
	}

/*------------------------------------------------------------------------------------------------------*/	
	//Prueba unitaria#1
	//Comprueba el funcionamiento del "encendido de la radio"
	@Test
	public void testRadioEncendida(){

		/*Imprime el valor inicial del boolean con el que se trabajo para 
		efectuar la simulación de encender la radio*/

		System.out.println("\nEl valor del boolean utilizado es: "+ isON());
		
		//Se "enciende" la radio

		encender();
		System.out.println("Encendiendo...");

		/*Se realiza la comparación entre lo que se tiene con lo esperado.
		Si en dado caso se cambia el valor true por false de la siguiente
		instrucción, la prueba dará a conocer que lo que se espera es true, 
		ya que la radio se encendió con anterioridad*/

		assertEquals(this.isON(), true);

		/*Como la prueba resulta exitosa continua con la impresión del nuevo valor
		del boolean que demostraría que efectivamente está "encendida"*/

		System.out.println("\nSi lees esto, la prueba resulto exitosa\n");
		System.out.println("Encendida con éxito!!!");
		System.out.println("El valor del boolean utilizado es: "+ isON());
	}

	//Prueba unitaria#2
	//Comprueba el tamaño del arreglo que se utilizó para guardar las emisoras
	@Test
	public void testTamaño(){

		//Se imprime el tamaño del arreglo que establecimos en clase
		System.out.println("\nTamaño del arreglo: " + Guardado.length);

		/*Se realiza la prueba que compara el tamaño del arreglo actual
		con el que se espera, que sería 12*/
		assertEquals(Guardado.length, 12);	

		//Como la prueba resulta exitosa lográ pasar a esta línea e imprime el mensaje
		System.out.println("Si lees esto, la prueba resulto exitosa");
	}

	//Prueba unitaria#3
	//Comprueba la efectividad del guardado de las emisoras
	@Test
	public void testGuardado(){

		/*Se imprime la lista de emisoras disponibles para mostrar que
		la prueba se realiza exitosamente y concuerda con el dato previsto*/
		for (int i = 0; i < Guardado.length; i++){
			System.out.println("Emisoras " + i + ": " + Guardado[i]);
		}

		/*Se realiza la prueba que compara el dato que se encuentra en el 
		espacio 5 del arreglo con el que sería, en teoría, 87*/
		assertEquals(Guardado[5], 87);


		//Como la prueba resulta exitosa lográ pasar a esta línea e imprime el mensaje
		System.out.println("\nSi lees esto, la prueba resulto exitosa");

	}

/*-------------------------------------------------------------------------------------------------------*/ 
}

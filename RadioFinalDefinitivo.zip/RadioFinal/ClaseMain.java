/******************************************************************

Christopher García 20541
Rodrigo Barrera 20807
3er. Semestre UVG
HT1-Estructura de datos
Fecha de creación: 16/01/2021 15:00 hrs.
Fecha de última modificación: 21/01/2021 

******************************************************************/

//Se importa Scanner para poder solicitar datos al usuario
import java.util.Scanner;

//Inicio del main
public class ClaseMain {

	public static void main(String[] args) {
		
		//Se crean las instancias tanto de la clase RadioCrtl(Contiene los métodos) como del Scanner
		RadioCrtl radio=new RadioCrtl();
		Scanner entrada=new Scanner(System.in);
		
		/*Variables que nos sirven para manejar datos o condicionales*/
		int opcion=0,opcion1=0, num=0,num1=1, ayuda=0;
		
		System.out.println("------------RADIO R AND CHR --------------");
		
		while (!radio.isON() && ayuda==0) {
			
			/*Try-Catch para proteger el funcionamiento*/
			try {
				
				/*Menú para la encender la radio*/
				System.out.println("�Desea encender la radio?" + "\n1. SI " + "\n2. NO");
				opcion=entrada.nextInt();
				
				/*Condicional Switch-Case para encender y apagar la radio*/
				switch(opcion) {
				
				/*Case que maneja la opci�n encender la radio*/
				case 1:
					
					System.out.println("Radio Encendida");
					radio.encender();
					ayuda=1;
					break;
					
				/*Case para volver a pedirle al usuario ingresar una opcion en dado caso ponga no*/	
					
				case 2:
					
					System.out.println("\nLo siento, pero no puedo trabajar con la radio apagada");
					System.out.println("Ingrese una opcion...\n");
					break;
					
				/*Default en dado caso el usuario se pase del rango permitido de opciones*/	
				default:
					
					System.out.println("Fuera de rango...");
					break;

				}
			
			}catch(Exception e) {
				
				System.out.println("Solo deben ser datos numericos");
				ayuda=1;
				
			}

		}
		
		/*While para manejar el menú de la radio encendida*/
		while(radio.isON()==true) {
			
			/*Try-Catch para proteger funcionamiento de lo que ingrese el usuario*/
			try {
				
				/*Menú de opciones para la radio*/
				System.out.println("\nQue accion desea realizar? "+ "\n1. Apagar " + "\n2. Escoger frecuencia (AM O FM) "+"\n3. Guardar una Emisora" + "\n4. Siguiente emisora " + "\n5. Seleccionar emisora guardada");
				opcion1=entrada.nextInt();
				System.out.println();
				
				/*Switch - Case para seleccionar las opciones disponibles del men�*/
				switch(opcion1) {
				
				/*Case para apagar la radio*/
				case 1:
					System.out.println("\nRadio Apagada\n");
					radio.apagar();
					break;
				/*Case que permite la opcion de seleccionar la frecuencia AM o FM*/
				case 2:
					radio.frecuencia();
					break;
				/*Case que permite guardar una emisora favorita al listado */
				case 3:
					radio.asignar(num);
					break;
				/*Case que incrementa el numero de la frecuencia que estamos escuchando*/
				case 4:
					radio.incrementar();
					break;
				/*Case que permite seleccionar una de las emisoras guardadas*/
				case 5:
					radio.emisora(num1);
					break;
				default:
					System.out.println("Fuera de rango...");
				}
				
			}catch(Exception e) {
				
				System.out.println("Solo deben ser datos numericos");
				radio.apagar();
			
			}
		}
		entrada.close();
	}
}

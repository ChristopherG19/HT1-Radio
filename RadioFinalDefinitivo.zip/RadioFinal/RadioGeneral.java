/******************************************************************

Christopher García 20541
Rodrigo Barrera 20807
3er. Semestre UVG
HT1-Estructura de datos
Fecha de creación: 16/01/2021 15:00 hrs.
Fecha de última modificación: 21/01/2021 

******************************************************************/
/*Interfaz propuesta en clase para que todos utilizarán los mismos nombres en sus métodos*/
public interface RadioGeneral {
	
	//Métodos que debe de presentar obligatoriamente la clase RadioCrtl

	//Verifica si la radio está encendida o apagada
	public abstract boolean isON();
	//"Enciende" la radio cambiando el estado del método anterior (De false a true)
	public abstract void  encender();
	//"Apaga" la radio y cambia el estado del método isOn (De true a false)
	public abstract void apagar();
	//Se utiliza para cambiar de emisora incrementa la misma
	public abstract void incrementar();
	//Se utiliza para asignar una emisora a uno de los botones de la radio (Del 1 al 12)
	public abstract boolean asignar(int num);
	//Se utiliza para cambiar de frecuencia entre AM y FM
	public abstract void frecuencia();
	//Se utiliza para sintonizar una emisora guardada en algún botón
	public abstract boolean emisora(int num);
	
}





